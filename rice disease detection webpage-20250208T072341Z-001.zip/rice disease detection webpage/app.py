from flask import Flask, render_template, request, redirect, url_for
import tensorflow as tf
from tensorflow.keras.models import load_model
import numpy as np
import os
from werkzeug.utils import secure_filename
from PIL import Image

app = Flask(__name__)
app.config['UPLOAD_FOLDER'] = 'static/uploads/'

# Load the trained model
model = load_model('Cats_and_Dogs_Image_classify.keras')

# Define class labels
class_labels = ['Bacterial Blight', 'Brown Spot', 'Leaf Blast']

# Function to preprocess the image
def preprocess_image(image_path):
    img = Image.open(image_path)
    img = img.resize((224, 224))  # Resize image to match model input size
    img = np.array(img) / 255.0  # Normalize pixel values
    img = np.expand_dims(img, axis=0)  # Add batch dimension
    return img

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    if 'image' not in request.files:
        return redirect(url_for('home'))
    file = request.files['image']
    if file.filename == '':
        return redirect(url_for('home'))
    
    filename = secure_filename(file.filename)
    filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
    file.save(filepath)
    
    # Preprocess the image and predict
    img = preprocess_image(filepath)
    predictions = model.predict(img)
    predicted_class = class_labels[np.argmax(predictions)]
    
    # Disease details (mocked data, replace with actual information)
    disease_info = {
        'Bacterial Blight': {
            'info': 'Bacterial blight causes wilting and yellowing of leaves.',
            'remedies': 'Use disease-resistant varieties, avoid waterlogging.',
            'pesticides': 'Copper-based bactericides'
        },
        'Brown Spot': {
            'info': 'Brown spots appear on leaves, reducing yield.',
            'remedies': 'Apply balanced fertilizers, avoid excess nitrogen.',
            'pesticides': 'Mancozeb, Propiconazole'
        },
        'Leaf Blast': {
            'info': 'Fungal infection causing lesions on leaves.',
            'remedies': 'Use resistant varieties, avoid high nitrogen use.',
            'pesticides': 'Tricyclazole, Carbendazim'
        }
    }
    
    result_data = disease_info[predicted_class]
    return render_template('result.html', disease_name=predicted_class, image_url=filepath,
                           disease_info=result_data['info'], remedies=result_data['remedies'], 
                           pesticides=result_data['pesticides'])

if __name__ == '__main__':
    app.run(debug=True)