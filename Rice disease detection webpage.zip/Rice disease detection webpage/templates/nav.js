// JavaScript code can be added here for interactions
document.addEventListener("DOMContentLoaded", function() {
    const dropdown = document.querySelector("nav li");
    dropdown.addEventListener("mouseenter", function() {
        this.querySelector(".dropdown-content").style.display = "block";
    });
    dropdown.addEventListener("mouseleave", function() {
        this.querySelector(".dropdown-content").style.display = "none";
    });
});